package service

import (
	"context"
	"tiny-template/src/api/page/transport"
)

func (s service) GetPageByID(ctx context.Context, req *transport.GetPageByIDRequest) (*transport.GetPageByIDResponse, error) {
	//TODO implement me
	panic("implement me")
}
