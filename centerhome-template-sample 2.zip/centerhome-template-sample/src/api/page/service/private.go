package service

const (
	filterLimit = 100
)
