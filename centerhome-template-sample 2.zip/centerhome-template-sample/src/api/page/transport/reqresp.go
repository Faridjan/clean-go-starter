package transport

type (
	GetPageByIDRequest struct {
	}

	GetPageByIDResponse struct {
	}
)
