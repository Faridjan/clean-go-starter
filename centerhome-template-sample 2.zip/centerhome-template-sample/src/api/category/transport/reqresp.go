package transport

type (
	GetCategoryByIDRequest struct {
	}

	GetCategoryByIDResponse struct {
	}
)
