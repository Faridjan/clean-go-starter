package service

import (
	"context"
	"tiny-template/src/api/category/transport"
)

func (s service) GetCategoryByID(ctx context.Context, req *transport.GetCategoryByIDRequest) (*transport.GetCategoryByIDResponse, error) {
	//TODO implement me
	panic("implement me")
}
